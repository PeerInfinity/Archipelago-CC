
-- TODO: Replace the tinting code with an actual rendered picture of the energy bridge icon.
-- This tint is so that one is less likely to accidentally mass-produce energy-bridges, then wonder why their rocket is not building.
function energy_bridge_tint()
    return { r = 0, g = 1, b = 0.667, a = 1}
end
function tint_icon(obj, tint)
    obj.icons = { {icon = obj.icon, icon_size = obj.icon_size, icon_mipmaps = obj.icon_mipmaps, tint = tint} }
    obj.icon = nil
    obj.icon_size = nil
    obj.icon_mipmaps = nil
end
local energy_bridge = table.deepcopy(data.raw["accumulator"]["accumulator"])
energy_bridge.name = "ap-energy-bridge"
energy_bridge.minable.result = "ap-energy-bridge"
energy_bridge.localised_name = "Archipelago EnergyLink Bridge"
energy_bridge.energy_source.buffer_capacity = "50MJ"
energy_bridge.energy_source.input_flow_limit = "10MW"
energy_bridge.energy_source.output_flow_limit = "10MW"
tint_icon(energy_bridge, energy_bridge_tint())
energy_bridge.chargable_graphics.picture.layers[1].tint = energy_bridge_tint()
energy_bridge.chargable_graphics.charge_animation.layers[1].layers[1].tint = energy_bridge_tint()
energy_bridge.chargable_graphics.discharge_animation.layers[1].layers[1].tint = energy_bridge_tint()
data.raw["accumulator"]["ap-energy-bridge"] = energy_bridge

local energy_bridge_item = table.deepcopy(data.raw["item"]["accumulator"])
energy_bridge_item.name = "ap-energy-bridge"
energy_bridge_item.localised_name = "Archipelago EnergyLink Bridge"
energy_bridge_item.place_result = energy_bridge.name
tint_icon(energy_bridge_item, energy_bridge_tint())
data.raw["item"]["ap-energy-bridge"] = energy_bridge_item

local energy_bridge_recipe = table.deepcopy(data.raw["recipe"]["accumulator"])
energy_bridge_recipe.name = "ap-energy-bridge"
energy_bridge_recipe.results = { {type = "item", name = energy_bridge_item.name, amount = 1} }
energy_bridge_recipe.energy_required = 1
energy_bridge_recipe.enabled = false
energy_bridge_recipe.localised_name = "Archipelago EnergyLink Bridge"
data.raw["recipe"]["ap-energy-bridge"] = energy_bridge_recipe

data.raw["map-gen-presets"].default["archipelago"] = {["default"] = false,
["order"] = "a",
["basic_settings"] = {["peaceful_mode"] = false,
["seed"] = 275665234,
["starting_area"] = 1.0,
["autoplace_controls"] = {["coal"] = {["frequency"] = 1.0,
["richness"] = 6.0,
["size"] = 3.0
}
,
["copper-ore"] = {["frequency"] = 1.0,
["richness"] = 6.0,
["size"] = 3.0
}
,
["crude-oil"] = {["frequency"] = 1.0,
["richness"] = 6.0,
["size"] = 3.0
}
,
["enemy-base"] = {["frequency"] = 1.0,
["richness"] = 1.0,
["size"] = 1.0
}
,
["iron-ore"] = {["frequency"] = 1.0,
["richness"] = 6.0,
["size"] = 3.0
}
,
["nauvis_cliff"] = {["frequency"] = 1.0,
["richness"] = 1.0,
["size"] = 1.0
}
,
["starting_area_moisture"] = {["frequency"] = 1.0,
["richness"] = 1.0,
["size"] = 1.0
}
,
["stone"] = {["frequency"] = 1.0,
["richness"] = 6.0,
["size"] = 3.0
}
,
["trees"] = {["frequency"] = 1.0,
["richness"] = 1.0,
["size"] = 1.0
}
,
["uranium-ore"] = {["frequency"] = 1.0,
["richness"] = 6.0,
["size"] = 3.0
}
,
["water"] = {["frequency"] = 1.0,
["richness"] = 1.0,
["size"] = 1.0
}

}
,
["cliff_settings"] = {["cliff_elevation_0"] = 10.0,
["cliff_elevation_interval"] = 40.0,
["name"] = "cliff",
["richness"] = 1.0
}
,
["property_expression_names"] = {["control-setting:aux:bias"] = 0.0,
["control-setting:aux:frequency:multiplier"] = 1.0,
["control-setting:moisture:bias"] = 0.0,
["control-setting:moisture:frequency:multiplier"] = 1.0
}

}
,
["advanced_settings"] = {["enemy_evolution"] = {["destroy_factor"] = 0.002,
["enabled"] = true,
["pollution_factor"] = 9e-07,
["time_factor"] = 4e-06
}
,
["enemy_expansion"] = {["enabled"] = true,
["max_expansion_cooldown"] = 216000.0,
["max_expansion_distance"] = 7.0,
["min_expansion_cooldown"] = 14400.0,
["settler_group_max_size"] = 20.0,
["settler_group_min_size"] = 5.0
}
,
["pollution"] = {["ageing"] = 1.0,
["diffusion_ratio"] = 0.02,
["enabled"] = true,
["enemy_attack_pollution_consumption_modifier"] = 1.0,
["min_pollution_to_damage_trees"] = 60.0,
["pollution_restored_per_tree_damage"] = 10.0
}

}

}

if mods["science-not-invited"] then
    local weights = {
        ["automation-science-pack"] =   0, -- Red science
        ["logistic-science-pack"]   =   0, -- Green science
        ["military-science-pack"]   =   0, -- Black science
        ["chemical-science-pack"]   =   0, -- Blue science
        ["production-science-pack"] =   0, -- Purple science
        ["utility-science-pack"]    =   0, -- Yellow science
        ["space-science-pack"]      =   0  -- Space science
    }
weights["space-science-pack"] = 1
weights["automation-science-pack"] = 1
weights["utility-science-pack"] = 1
weights["logistic-science-pack"] = 1
weights["chemical-science-pack"] = 1
weights["military-science-pack"] = 1
weights["production-science-pack"] = 1

    SNI.setWeights(weights)
end