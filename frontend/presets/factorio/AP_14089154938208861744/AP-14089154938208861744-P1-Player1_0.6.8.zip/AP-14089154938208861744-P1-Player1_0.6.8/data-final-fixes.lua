
-- this file gets written automatically by the Archipelago Randomizer and is in its raw form a Jinja2 Template
require('lib')
data.raw["item"]["rocket-part"].hidden = false
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes = {
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { 0, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { 0, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, 0 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, 0 } }
        }
    },
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { -3, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { -3, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, -3 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, -3 } }
        }
    },
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { 3, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { 3, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, 3 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, 3 } }
        }
    }
}
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes_off_when_no_fluid_recipe = true
data.raw["recipe"]["rocket-part"].category = "rocket-building"
data.raw["recipe"]["rocket-part"].ingredients = {{type = "item", name = "night-vision-equipment", amount = 10},
{type = "item", name = "flamethrower-turret", amount = 10},
{type = "item", name = "electric-furnace", amount = 10}
}
data.raw["recipe"]["ap-energy-bridge"].category = "crafting"
data.raw["recipe"]["ap-energy-bridge"].ingredients = {{type = "item", name = "transport-belt", amount = 218},
{type = "item", name = "stone-brick", amount = 208},
{type = "item", name = "stone", amount = 168},
{type = "item", name = "pipe", amount = 87},
{type = "item", name = "iron-plate", amount = 461},
{type = "item", name = "iron-ore", amount = 485}
}

local technologies = data.raw["technology"]
local new_tree_copy

local template_tech = table.deepcopy(technologies["automation"])
template_tech.unlocks = {}
template_tech.upgrade = false
template_tech.effects = {}
template_tech.prerequisites = {}

function set_ap_icon(tech)
    tech.icon = "__AP-14089154938208861744-P1-Player1__/graphics/icons/ap.png"
    tech.icons = nil
    tech.icon_size = 128
end

function set_ap_unimportant_icon(tech)
    tech.icon = "__AP-14089154938208861744-P1-Player1__/graphics/icons/ap_unimportant.png"
    tech.icons = nil
    tech.icon_size = 128
end

function copy_factorio_icon(tech, tech_source)
    tech.icon = table.deepcopy(technologies[tech_source].icon)
    tech.icons = table.deepcopy(technologies[tech_source].icons)
    tech.icon_size = table.deepcopy(technologies[tech_source].icon_size)
end


function adjust_energy(recipe_name, factor)
    local recipe = data.raw.recipe[recipe_name]
    local energy = recipe.energy_required

    if (recipe.normal ~= nil) then
        if (recipe.normal.energy_required == nil) then
            energy = 0.5
        else
            energy = recipe.normal.energy_required
        end
        recipe.normal.energy_required = energy * factor
    end
    if (recipe.expensive ~= nil) then
        if (recipe.expensive.energy_required == nil) then
            energy = 0.5
        else
            energy = recipe.expensive.energy_required
        end
        recipe.expensive.energy_required = energy * factor
    end
    if (energy ~= nil) then
        data.raw.recipe[recipe_name].energy_required = energy * factor
    elseif (recipe.expensive == nil and recipe.normal == nil) then
        data.raw.recipe[recipe_name].energy_required = 0.5 * factor
    end
end

function set_energy(recipe_name, energy)
    local recipe = data.raw.recipe[recipe_name]

    if (recipe.normal ~= nil) then
        recipe.normal.energy_required = energy
    end
    if (recipe.expensive ~= nil) then
        recipe.expensive.energy_required = energy
    end
    if (recipe.expensive == nil and recipe.normal == nil) then
        recipe.energy_required = energy
    end
end

data.raw["assembling-machine"]["assembling-machine-1"].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
data.raw["assembling-machine"]["assembling-machine-2"].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
data.raw["assembling-machine"]["assembling-machine-1"].fluid_boxes = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes)
data.raw["assembling-machine"]["assembling-machine-1"].fluid_boxes_off_when_no_fluid_recipe = data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes_off_when_no_fluid_recipe
if mods["factory-levels"] then
    -- Factory-Levels allows the assembling machines to get faster (and depending on settings), more productive at crafting products, the more the
    -- assembling machine crafts the product.  If the machine crafts enough, it may auto-upgrade to the next tier.
    for i = 1, 25, 1 do
        data.raw["assembling-machine"]["assembling-machine-1-level-" .. i].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
        data.raw["assembling-machine"]["assembling-machine-1-level-" .. i].fluid_boxes = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes)
    end
    for i = 1, 50, 1 do
        data.raw["assembling-machine"]["assembling-machine-2-level-" .. i].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
    end
end

data.raw["ammo"]["artillery-shell"].stack_size = 10

technologies["advanced-circuit"].hidden = true
technologies["advanced-circuit"].hidden_in_factoriopedia = true
technologies["advanced-combinators"].hidden = true
technologies["advanced-combinators"].hidden_in_factoriopedia = true
technologies["advanced-material-processing"].hidden = true
technologies["advanced-material-processing"].hidden_in_factoriopedia = true
technologies["advanced-material-processing-2"].hidden = true
technologies["advanced-material-processing-2"].hidden_in_factoriopedia = true
technologies["advanced-oil-processing"].hidden = true
technologies["advanced-oil-processing"].hidden_in_factoriopedia = true
technologies["artillery"].hidden = true
technologies["artillery"].hidden_in_factoriopedia = true
technologies["atomic-bomb"].hidden = true
technologies["atomic-bomb"].hidden_in_factoriopedia = true
technologies["automated-rail-transportation"].hidden = true
technologies["automated-rail-transportation"].hidden_in_factoriopedia = true
technologies["automation"].hidden = true
technologies["automation"].hidden_in_factoriopedia = true
technologies["automation-2"].hidden = true
technologies["automation-2"].hidden_in_factoriopedia = true
technologies["automation-3"].hidden = true
technologies["automation-3"].hidden_in_factoriopedia = true
technologies["automation-science-pack"].hidden = true
technologies["automation-science-pack"].hidden_in_factoriopedia = true
technologies["automobilism"].hidden = true
technologies["automobilism"].hidden_in_factoriopedia = true
technologies["battery"].hidden = true
technologies["battery"].hidden_in_factoriopedia = true
technologies["battery-equipment"].hidden = true
technologies["battery-equipment"].hidden_in_factoriopedia = true
technologies["battery-mk2-equipment"].hidden = true
technologies["battery-mk2-equipment"].hidden_in_factoriopedia = true
technologies["belt-immunity-equipment"].hidden = true
technologies["belt-immunity-equipment"].hidden_in_factoriopedia = true
technologies["braking-force-1"].hidden = true
technologies["braking-force-1"].hidden_in_factoriopedia = true
technologies["braking-force-2"].hidden = true
technologies["braking-force-2"].hidden_in_factoriopedia = true
technologies["braking-force-3"].hidden = true
technologies["braking-force-3"].hidden_in_factoriopedia = true
technologies["braking-force-4"].hidden = true
technologies["braking-force-4"].hidden_in_factoriopedia = true
technologies["braking-force-5"].hidden = true
technologies["braking-force-5"].hidden_in_factoriopedia = true
technologies["braking-force-6"].hidden = true
technologies["braking-force-6"].hidden_in_factoriopedia = true
technologies["braking-force-7"].hidden = true
technologies["braking-force-7"].hidden_in_factoriopedia = true
technologies["bulk-inserter"].hidden = true
technologies["bulk-inserter"].hidden_in_factoriopedia = true
technologies["chemical-science-pack"].hidden = true
technologies["chemical-science-pack"].hidden_in_factoriopedia = true
technologies["circuit-network"].hidden = true
technologies["circuit-network"].hidden_in_factoriopedia = true
technologies["cliff-explosives"].hidden = true
technologies["cliff-explosives"].hidden_in_factoriopedia = true
technologies["coal-liquefaction"].hidden = true
technologies["coal-liquefaction"].hidden_in_factoriopedia = true
technologies["concrete"].hidden = true
technologies["concrete"].hidden_in_factoriopedia = true
technologies["construction-robotics"].hidden = true
technologies["construction-robotics"].hidden_in_factoriopedia = true
technologies["defender"].hidden = true
technologies["defender"].hidden_in_factoriopedia = true
technologies["destroyer"].hidden = true
technologies["destroyer"].hidden_in_factoriopedia = true
technologies["discharge-defense-equipment"].hidden = true
technologies["discharge-defense-equipment"].hidden_in_factoriopedia = true
technologies["distractor"].hidden = true
technologies["distractor"].hidden_in_factoriopedia = true
technologies["effect-transmission"].hidden = true
technologies["effect-transmission"].hidden_in_factoriopedia = true
technologies["efficiency-module"].hidden = true
technologies["efficiency-module"].hidden_in_factoriopedia = true
technologies["efficiency-module-2"].hidden = true
technologies["efficiency-module-2"].hidden_in_factoriopedia = true
technologies["efficiency-module-3"].hidden = true
technologies["efficiency-module-3"].hidden_in_factoriopedia = true
technologies["electric-energy-accumulators"].hidden = true
technologies["electric-energy-accumulators"].hidden_in_factoriopedia = true
technologies["electric-energy-distribution-1"].hidden = true
technologies["electric-energy-distribution-1"].hidden_in_factoriopedia = true
technologies["electric-energy-distribution-2"].hidden = true
technologies["electric-energy-distribution-2"].hidden_in_factoriopedia = true
technologies["electric-engine"].hidden = true
technologies["electric-engine"].hidden_in_factoriopedia = true
technologies["electric-mining-drill"].hidden = true
technologies["electric-mining-drill"].hidden_in_factoriopedia = true
technologies["electronics"].hidden = true
technologies["electronics"].hidden_in_factoriopedia = true
technologies["energy-shield-equipment"].hidden = true
technologies["energy-shield-equipment"].hidden_in_factoriopedia = true
technologies["energy-shield-mk2-equipment"].hidden = true
technologies["energy-shield-mk2-equipment"].hidden_in_factoriopedia = true
technologies["engine"].hidden = true
technologies["engine"].hidden_in_factoriopedia = true
technologies["exoskeleton-equipment"].hidden = true
technologies["exoskeleton-equipment"].hidden_in_factoriopedia = true
technologies["explosive-rocketry"].hidden = true
technologies["explosive-rocketry"].hidden_in_factoriopedia = true
technologies["explosives"].hidden = true
technologies["explosives"].hidden_in_factoriopedia = true
technologies["fast-inserter"].hidden = true
technologies["fast-inserter"].hidden_in_factoriopedia = true
technologies["fission-reactor-equipment"].hidden = true
technologies["fission-reactor-equipment"].hidden_in_factoriopedia = true
technologies["flamethrower"].hidden = true
technologies["flamethrower"].hidden_in_factoriopedia = true
technologies["flammables"].hidden = true
technologies["flammables"].hidden_in_factoriopedia = true
technologies["fluid-handling"].hidden = true
technologies["fluid-handling"].hidden_in_factoriopedia = true
technologies["fluid-wagon"].hidden = true
technologies["fluid-wagon"].hidden_in_factoriopedia = true
technologies["follower-robot-count-1"].hidden = true
technologies["follower-robot-count-1"].hidden_in_factoriopedia = true
technologies["follower-robot-count-2"].hidden = true
technologies["follower-robot-count-2"].hidden_in_factoriopedia = true
technologies["follower-robot-count-3"].hidden = true
technologies["follower-robot-count-3"].hidden_in_factoriopedia = true
technologies["follower-robot-count-4"].hidden = true
technologies["follower-robot-count-4"].hidden_in_factoriopedia = true
technologies["gate"].hidden = true
technologies["gate"].hidden_in_factoriopedia = true
technologies["gun-turret"].hidden = true
technologies["gun-turret"].hidden_in_factoriopedia = true
technologies["heavy-armor"].hidden = true
technologies["heavy-armor"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-1"].hidden = true
technologies["inserter-capacity-bonus-1"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-2"].hidden = true
technologies["inserter-capacity-bonus-2"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-3"].hidden = true
technologies["inserter-capacity-bonus-3"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-4"].hidden = true
technologies["inserter-capacity-bonus-4"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-5"].hidden = true
technologies["inserter-capacity-bonus-5"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-6"].hidden = true
technologies["inserter-capacity-bonus-6"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-7"].hidden = true
technologies["inserter-capacity-bonus-7"].hidden_in_factoriopedia = true
technologies["kovarex-enrichment-process"].hidden = true
technologies["kovarex-enrichment-process"].hidden_in_factoriopedia = true
technologies["lamp"].hidden = true
technologies["lamp"].hidden_in_factoriopedia = true
technologies["land-mine"].hidden = true
technologies["land-mine"].hidden_in_factoriopedia = true
technologies["landfill"].hidden = true
technologies["landfill"].hidden_in_factoriopedia = true
technologies["laser"].hidden = true
technologies["laser"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-1"].hidden = true
technologies["laser-shooting-speed-1"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-2"].hidden = true
technologies["laser-shooting-speed-2"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-3"].hidden = true
technologies["laser-shooting-speed-3"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-4"].hidden = true
technologies["laser-shooting-speed-4"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-5"].hidden = true
technologies["laser-shooting-speed-5"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-6"].hidden = true
technologies["laser-shooting-speed-6"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-7"].hidden = true
technologies["laser-shooting-speed-7"].hidden_in_factoriopedia = true
technologies["laser-turret"].hidden = true
technologies["laser-turret"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-1"].hidden = true
technologies["laser-weapons-damage-1"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-2"].hidden = true
technologies["laser-weapons-damage-2"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-3"].hidden = true
technologies["laser-weapons-damage-3"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-4"].hidden = true
technologies["laser-weapons-damage-4"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-5"].hidden = true
technologies["laser-weapons-damage-5"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-6"].hidden = true
technologies["laser-weapons-damage-6"].hidden_in_factoriopedia = true
technologies["logistic-robotics"].hidden = true
technologies["logistic-robotics"].hidden_in_factoriopedia = true
technologies["logistic-science-pack"].hidden = true
technologies["logistic-science-pack"].hidden_in_factoriopedia = true
technologies["logistic-system"].hidden = true
technologies["logistic-system"].hidden_in_factoriopedia = true
technologies["logistics"].hidden = true
technologies["logistics"].hidden_in_factoriopedia = true
technologies["logistics-2"].hidden = true
technologies["logistics-2"].hidden_in_factoriopedia = true
technologies["logistics-3"].hidden = true
technologies["logistics-3"].hidden_in_factoriopedia = true
technologies["low-density-structure"].hidden = true
technologies["low-density-structure"].hidden_in_factoriopedia = true
technologies["lubricant"].hidden = true
technologies["lubricant"].hidden_in_factoriopedia = true
technologies["military"].hidden = true
technologies["military"].hidden_in_factoriopedia = true
technologies["military-2"].hidden = true
technologies["military-2"].hidden_in_factoriopedia = true
technologies["military-3"].hidden = true
technologies["military-3"].hidden_in_factoriopedia = true
technologies["military-4"].hidden = true
technologies["military-4"].hidden_in_factoriopedia = true
technologies["military-science-pack"].hidden = true
technologies["military-science-pack"].hidden_in_factoriopedia = true
technologies["mining-productivity-1"].hidden = true
technologies["mining-productivity-1"].hidden_in_factoriopedia = true
technologies["mining-productivity-2"].hidden = true
technologies["mining-productivity-2"].hidden_in_factoriopedia = true
technologies["mining-productivity-3"].hidden = true
technologies["mining-productivity-3"].hidden_in_factoriopedia = true
technologies["modular-armor"].hidden = true
technologies["modular-armor"].hidden_in_factoriopedia = true
technologies["modules"].hidden = true
technologies["modules"].hidden_in_factoriopedia = true
technologies["night-vision-equipment"].hidden = true
technologies["night-vision-equipment"].hidden_in_factoriopedia = true
technologies["nuclear-fuel-reprocessing"].hidden = true
technologies["nuclear-fuel-reprocessing"].hidden_in_factoriopedia = true
technologies["nuclear-power"].hidden = true
technologies["nuclear-power"].hidden_in_factoriopedia = true
technologies["oil-gathering"].hidden = true
technologies["oil-gathering"].hidden_in_factoriopedia = true
technologies["oil-processing"].hidden = true
technologies["oil-processing"].hidden_in_factoriopedia = true
technologies["personal-laser-defense-equipment"].hidden = true
technologies["personal-laser-defense-equipment"].hidden_in_factoriopedia = true
technologies["personal-roboport-equipment"].hidden = true
technologies["personal-roboport-equipment"].hidden_in_factoriopedia = true
technologies["personal-roboport-mk2-equipment"].hidden = true
technologies["personal-roboport-mk2-equipment"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-1"].hidden = true
technologies["physical-projectile-damage-1"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-2"].hidden = true
technologies["physical-projectile-damage-2"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-3"].hidden = true
technologies["physical-projectile-damage-3"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-4"].hidden = true
technologies["physical-projectile-damage-4"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-5"].hidden = true
technologies["physical-projectile-damage-5"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-6"].hidden = true
technologies["physical-projectile-damage-6"].hidden_in_factoriopedia = true
technologies["plastics"].hidden = true
technologies["plastics"].hidden_in_factoriopedia = true
technologies["power-armor"].hidden = true
technologies["power-armor"].hidden_in_factoriopedia = true
technologies["power-armor-mk2"].hidden = true
technologies["power-armor-mk2"].hidden_in_factoriopedia = true
technologies["processing-unit"].hidden = true
technologies["processing-unit"].hidden_in_factoriopedia = true
technologies["production-science-pack"].hidden = true
technologies["production-science-pack"].hidden_in_factoriopedia = true
technologies["productivity-module"].hidden = true
technologies["productivity-module"].hidden_in_factoriopedia = true
technologies["productivity-module-2"].hidden = true
technologies["productivity-module-2"].hidden_in_factoriopedia = true
technologies["productivity-module-3"].hidden = true
technologies["productivity-module-3"].hidden_in_factoriopedia = true
technologies["radar"].hidden = true
technologies["radar"].hidden_in_factoriopedia = true
technologies["railway"].hidden = true
technologies["railway"].hidden_in_factoriopedia = true
technologies["refined-flammables-1"].hidden = true
technologies["refined-flammables-1"].hidden_in_factoriopedia = true
technologies["refined-flammables-2"].hidden = true
technologies["refined-flammables-2"].hidden_in_factoriopedia = true
technologies["refined-flammables-3"].hidden = true
technologies["refined-flammables-3"].hidden_in_factoriopedia = true
technologies["refined-flammables-4"].hidden = true
technologies["refined-flammables-4"].hidden_in_factoriopedia = true
technologies["refined-flammables-5"].hidden = true
technologies["refined-flammables-5"].hidden_in_factoriopedia = true
technologies["refined-flammables-6"].hidden = true
technologies["refined-flammables-6"].hidden_in_factoriopedia = true
technologies["repair-pack"].hidden = true
technologies["repair-pack"].hidden_in_factoriopedia = true
technologies["research-speed-1"].hidden = true
technologies["research-speed-1"].hidden_in_factoriopedia = true
technologies["research-speed-2"].hidden = true
technologies["research-speed-2"].hidden_in_factoriopedia = true
technologies["research-speed-3"].hidden = true
technologies["research-speed-3"].hidden_in_factoriopedia = true
technologies["research-speed-4"].hidden = true
technologies["research-speed-4"].hidden_in_factoriopedia = true
technologies["research-speed-5"].hidden = true
technologies["research-speed-5"].hidden_in_factoriopedia = true
technologies["research-speed-6"].hidden = true
technologies["research-speed-6"].hidden_in_factoriopedia = true
technologies["robotics"].hidden = true
technologies["robotics"].hidden_in_factoriopedia = true
technologies["rocket-fuel"].hidden = true
technologies["rocket-fuel"].hidden_in_factoriopedia = true
technologies["rocket-silo"].hidden = true
technologies["rocket-silo"].hidden_in_factoriopedia = true
technologies["rocketry"].hidden = true
technologies["rocketry"].hidden_in_factoriopedia = true
technologies["solar-energy"].hidden = true
technologies["solar-energy"].hidden_in_factoriopedia = true
technologies["solar-panel-equipment"].hidden = true
technologies["solar-panel-equipment"].hidden_in_factoriopedia = true
technologies["space-science-pack"].hidden = true
technologies["space-science-pack"].hidden_in_factoriopedia = true
technologies["speed-module"].hidden = true
technologies["speed-module"].hidden_in_factoriopedia = true
technologies["speed-module-2"].hidden = true
technologies["speed-module-2"].hidden_in_factoriopedia = true
technologies["speed-module-3"].hidden = true
technologies["speed-module-3"].hidden_in_factoriopedia = true
technologies["spidertron"].hidden = true
technologies["spidertron"].hidden_in_factoriopedia = true
technologies["steam-power"].hidden = true
technologies["steam-power"].hidden_in_factoriopedia = true
technologies["steel-axe"].hidden = true
technologies["steel-axe"].hidden_in_factoriopedia = true
technologies["steel-processing"].hidden = true
technologies["steel-processing"].hidden_in_factoriopedia = true
technologies["stone-wall"].hidden = true
technologies["stone-wall"].hidden_in_factoriopedia = true
technologies["stronger-explosives-1"].hidden = true
technologies["stronger-explosives-1"].hidden_in_factoriopedia = true
technologies["stronger-explosives-2"].hidden = true
technologies["stronger-explosives-2"].hidden_in_factoriopedia = true
technologies["stronger-explosives-3"].hidden = true
technologies["stronger-explosives-3"].hidden_in_factoriopedia = true
technologies["stronger-explosives-4"].hidden = true
technologies["stronger-explosives-4"].hidden_in_factoriopedia = true
technologies["stronger-explosives-5"].hidden = true
technologies["stronger-explosives-5"].hidden_in_factoriopedia = true
technologies["stronger-explosives-6"].hidden = true
technologies["stronger-explosives-6"].hidden_in_factoriopedia = true
technologies["sulfur-processing"].hidden = true
technologies["sulfur-processing"].hidden_in_factoriopedia = true
technologies["tank"].hidden = true
technologies["tank"].hidden_in_factoriopedia = true
technologies["toolbelt"].hidden = true
technologies["toolbelt"].hidden_in_factoriopedia = true
technologies["uranium-ammo"].hidden = true
technologies["uranium-ammo"].hidden_in_factoriopedia = true
technologies["uranium-mining"].hidden = true
technologies["uranium-mining"].hidden_in_factoriopedia = true
technologies["uranium-processing"].hidden = true
technologies["uranium-processing"].hidden_in_factoriopedia = true
technologies["utility-science-pack"].hidden = true
technologies["utility-science-pack"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-1"].hidden = true
technologies["weapon-shooting-speed-1"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-2"].hidden = true
technologies["weapon-shooting-speed-2"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-3"].hidden = true
technologies["weapon-shooting-speed-3"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-4"].hidden = true
technologies["weapon-shooting-speed-4"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-5"].hidden = true
technologies["weapon-shooting-speed-5"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-6"].hidden = true
technologies["weapon-shooting-speed-6"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-1"].hidden = true
technologies["worker-robots-speed-1"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-2"].hidden = true
technologies["worker-robots-speed-2"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-3"].hidden = true
technologies["worker-robots-speed-3"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-4"].hidden = true
technologies["worker-robots-speed-4"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-5"].hidden = true
technologies["worker-robots-speed-5"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-1"].hidden = true
technologies["worker-robots-storage-1"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-2"].hidden = true
technologies["worker-robots-storage-2"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-3"].hidden = true
technologies["worker-robots-storage-3"].hidden_in_factoriopedia = true

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131306-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-rocketry", "AP-1-235"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-rocketry", "Player1", ""}
new_tree_copy.unit.count = 136
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "rocketry")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135416-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-inserter", "AP-5-349"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-inserter", "Player1", ""}
new_tree_copy.unit.count = 185
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131869-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-processing", "AP-1-798"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 426
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135193-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-shooting-speed", "AP-5-126"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 93
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132398-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-vehicle", "AP-2-328"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-vehicle", "Player1", ""}
new_tree_copy.unit.count = 181
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "automobilism")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134499-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-processing", "AP-4-431"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 219
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133995-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-science-pack", "AP-3-926"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-science-pack", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 462
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131828-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-energy-shield", "AP-1-757"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-energy-shield", "Player1", ""}
new_tree_copy.unit.count = 389
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "energy-shield-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133482-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-physical-projectile-damage", "AP-3-413"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-physical-projectile-damage", "Player1", ""}
new_tree_copy.unit.count = 211
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134597-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-worker-robots-storage", "AP-4-529"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-worker-robots-storage", "Player1", ""}
new_tree_copy.unit.count = 273
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "worker-robots-storage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132486-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-research-speed", "AP-2-416"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-research-speed", "Player1", ""}
new_tree_copy.unit.count = 215
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134372-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-processing", "AP-4-304"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 176
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134092-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-flamethrower", "AP-4-024"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-flamethrower", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 25
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-137012-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "rocket-silo", "AP-6-946"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "rocket-silo", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 473
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "rocket-silo")
table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 1: night-vision-equipment"})

table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 2: flamethrower-turret"})

table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 3: electric-furnace"})

data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134237-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-physical-projectile-damage", "AP-4-169"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-physical-projectile-damage", "Player1", ""}
new_tree_copy.unit.count = 107
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135022-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-shooting-speed", "AP-4-954"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 480
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133110-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-logistics", "AP-3-041"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-logistics", "Player1", ""}
new_tree_copy.unit.count = 32
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134890-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-shooting-speed", "AP-4-822"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 432
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132249-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-mining-productivity", "AP-2-179"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-mining-productivity", "Player1", ""}
new_tree_copy.unit.count = 110
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "mining-productivity-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131168-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "toolbelt", "AP-1-097"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "toolbelt", "Player1", ""}
new_tree_copy.unit.count = 74
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "toolbelt")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132704-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-military", "AP-2-634"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-military", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 315
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134043-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-flamethrower", "AP-3-974"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-flamethrower", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 490
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132758-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "radar", "AP-2-688"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "radar", "Player1", ""}
new_tree_copy.unit.count = 358
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "radar")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134567-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-processing", "AP-4-499"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 251
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134806-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-follower", "AP-4-738"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-follower", "Player1", ""}
new_tree_copy.unit.count = 384
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "defender")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131212-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "logistic-robotics", "AP-1-141"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "logistic-robotics", "Player1", ""}
new_tree_copy.unit.count = 101
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "logistic-robotics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132753-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "advanced-circuit", "AP-2-683"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "advanced-circuit", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 346
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "advanced-circuit")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132720-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "rocket-fuel", "AP-2-650"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "rocket-fuel", "Player1", ""}
new_tree_copy.unit.count = 328
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "rocket-fuel")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131530-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-weapons-damage", "AP-1-459"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-weapons-damage", "Player1", ""}
new_tree_copy.unit.count = 221
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131126-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-logistics", "AP-1-055"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-logistics", "Player1", ""}
new_tree_copy.unit.count = 10
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135184-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "uranium-mining", "AP-5-117"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "uranium-mining", "Player1", ""}
new_tree_copy.unit.count = 85
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "uranium-mining")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132339-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-flamethrower", "AP-2-269"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-flamethrower", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 142
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135287-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "explosives", "AP-5-220"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "explosives", "Player1", ""}
new_tree_copy.unit.count = 136
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "explosives")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135405-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-stronger-explosives", "AP-5-338"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-stronger-explosives", "Player1", ""}
new_tree_copy.unit.count = 182
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134090-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-physical-projectile-damage", "AP-4-022"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-physical-projectile-damage", "Player1", ""}
new_tree_copy.unit.count = 20
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132483-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-weapon-shooting-speed", "AP-2-413"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-weapon-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 213
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132572-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "circuit-network", "AP-2-502"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "circuit-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 253
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "circuit-network")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133791-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-mining-productivity", "AP-3-722"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-mining-productivity", "Player1", ""}
new_tree_copy.unit.count = 373
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "mining-productivity-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133875-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-physical-projectile-damage", "AP-3-806"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-physical-projectile-damage", "Player1", ""}
new_tree_copy.unit.count = 430
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132594-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "advanced-combinators", "AP-2-524"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "advanced-combinators", "Player1", ""}
new_tree_copy.unit.count = 263
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "advanced-combinators")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131840-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-shooting-speed", "AP-1-769"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 403
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136077-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-worker-robots-speed", "AP-6-011"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-worker-robots-speed", "Player1", ""}
new_tree_copy.unit.count = 8
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134081-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "battery", "AP-4-013"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "battery", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 15
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "battery")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134917-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-productivity-module", "AP-4-849"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-productivity-module", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 439
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "productivity-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134668-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-physical-projectile-damage", "AP-4-600"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-physical-projectile-damage", "Player1", ""}
new_tree_copy.unit.count = 303
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134442-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-stronger-explosives", "AP-4-374"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-stronger-explosives", "Player1", ""}
new_tree_copy.unit.count = 194
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136068-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-worker-robots-speed", "AP-6-002"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-worker-robots-speed", "Player1", ""}
new_tree_copy.unit.count = 5
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132724-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "fission-reactor-equipment", "AP-2-654"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "fission-reactor-equipment", "Player1", ""}
new_tree_copy.unit.count = 333
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "fission-reactor-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134342-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-shooting-speed", "AP-4-274"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 152
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132342-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-research-speed", "AP-2-272"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-research-speed", "Player1", ""}
new_tree_copy.unit.count = 150
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133198-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "land-mine", "AP-3-129"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "land-mine", "Player1", ""}
new_tree_copy.unit.count = 99
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "land-mine")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132142-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-mining-productivity", "AP-2-072"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-mining-productivity", "Player1", ""}
new_tree_copy.unit.count = 47
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "mining-productivity-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132968-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-worker-robots-storage", "AP-2-898"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-worker-robots-storage", "Player1", ""}
new_tree_copy.unit.count = 454
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "worker-robots-storage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134764-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "effect-transmission", "AP-4-696"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "effect-transmission", "Player1", ""}
new_tree_copy.unit.count = 361
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "effect-transmission")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131704-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-science-pack", "AP-1-633"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-science-pack", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 306
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135040-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-science-pack", "AP-4-972"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-science-pack", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 490
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131147-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-follower-robot-count", "AP-1-076"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-follower-robot-count", "Player1", ""}
new_tree_copy.unit.count = 52
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133788-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-train-network", "AP-3-719"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-train-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 368
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131951-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-personal-battery", "AP-1-880"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-personal-battery", "Player1", ""}
new_tree_copy.unit.count = 445
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "battery-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135770-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-speed-module", "AP-5-703"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-speed-module", "Player1", ""}
new_tree_copy.unit.count = 367
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "speed-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131282-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "robotics", "AP-1-211"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "robotics", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 130
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "robotics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136742-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-automation", "AP-6-676"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-automation", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 338
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135802-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-research-speed", "AP-5-735"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-research-speed", "Player1", ""}
new_tree_copy.unit.count = 378
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132340-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-speed-module", "AP-2-270"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-speed-module", "Player1", ""}
new_tree_copy.unit.count = 148
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "speed-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135822-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-train-network", "AP-5-755"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-train-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 388
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131825-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "exoskeleton-equipment", "AP-1-754"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "exoskeleton-equipment", "Player1", ""}
new_tree_copy.unit.count = 387
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "exoskeleton-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132931-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-weapon-shooting-speed", "AP-2-861"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-weapon-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 439
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136143-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-logistics", "AP-6-077"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-logistics", "Player1", ""}
new_tree_copy.unit.count = 54
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132539-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "concrete", "AP-2-469"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "concrete", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 224
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "concrete")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135531-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-shooting-speed", "AP-5-464"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 222
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134023-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-weapon-shooting-speed", "AP-3-954"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-weapon-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 481
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133955-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-weapon-shooting-speed", "AP-3-886"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-weapon-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 447
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135067-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "solar-energy", "AP-4-999"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "solar-energy", "Player1", ""}
new_tree_copy.unit.count = 500
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "solar-energy")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135676-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-inserter", "AP-5-609"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-inserter", "Player1", ""}
new_tree_copy.unit.count = 304
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136267-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-train-network", "AP-6-201"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-train-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 122
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135383-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-efficiency-module", "AP-5-316"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-efficiency-module", "Player1", ""}
new_tree_copy.unit.count = 178
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "efficiency-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134897-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-inserter", "AP-4-829"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-inserter", "Player1", ""}
new_tree_copy.unit.count = 437
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133771-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-inserter", "AP-3-702"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-inserter", "Player1", ""}
new_tree_copy.unit.count = 362
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132054-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-engine", "AP-1-983"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-engine", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 493
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "engine")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134022-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-stronger-explosives", "AP-3-953"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-stronger-explosives", "Player1", ""}
new_tree_copy.unit.count = 478
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133066-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-follower", "AP-2-996"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-follower", "Player1", ""}
new_tree_copy.unit.count = 494
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "defender")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131151-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "nuclear-power", "AP-1-080"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "nuclear-power", "Player1", ""}
new_tree_copy.unit.count = 72
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "nuclear-power")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132971-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "lamp", "AP-2-901"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "lamp", "Player1", ""}
new_tree_copy.unit.count = 456
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "lamp")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135911-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "lubricant", "AP-5-844"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "lubricant", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 437
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "lubricant")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135801-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-flamethrower", "AP-5-734"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-flamethrower", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 375
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131546-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "processing-unit", "AP-1-475"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "processing-unit", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 243
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "processing-unit")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136259-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-inserter", "AP-6-193"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-inserter", "Player1", ""}
new_tree_copy.unit.count = 113
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131197-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-follower-robot-count", "AP-1-126"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-follower-robot-count", "Player1", ""}
new_tree_copy.unit.count = 95
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134474-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-follower-robot-count", "AP-4-406"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-follower-robot-count", "Player1", ""}
new_tree_copy.unit.count = 196
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132025-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-science-pack", "AP-1-954"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-science-pack", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 487
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136214-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-armor", "AP-6-148"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-armor", "Player1", ""}
new_tree_copy.unit.count = 102
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134895-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "repair-pack", "AP-4-827"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "repair-pack", "Player1", ""}
new_tree_copy.unit.count = 434
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "repair-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134477-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-productivity-module", "AP-4-409"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-productivity-module", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 207
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "productivity-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133309-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-processing", "AP-3-240"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 141
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133094-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-weapons-damage", "AP-3-025"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-weapons-damage", "Player1", ""}
new_tree_copy.unit.count = 27
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135200-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-turret", "AP-5-133"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-turret", "Player1", ""}
new_tree_copy.unit.count = 101
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "gun-turret")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132577-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-weapons-damage", "AP-2-507"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-weapons-damage", "Player1", ""}
new_tree_copy.unit.count = 258
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132655-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-flamethrower", "AP-2-585"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-flamethrower", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 299
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134418-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-military", "AP-4-350"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-military", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 187
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133535-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "landfill", "AP-3-466"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "landfill", "Player1", ""}
new_tree_copy.unit.count = 223
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "landfill")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135468-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-research-speed", "AP-5-401"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-research-speed", "Player1", ""}
new_tree_copy.unit.count = 195
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132022-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-worker-robots-storage", "AP-1-951"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-worker-robots-storage", "Player1", ""}
new_tree_copy.unit.count = 477
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "worker-robots-storage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133279-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-train-network", "AP-3-210"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-train-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 127
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131150-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "belt-immunity-equipment", "AP-1-079"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "belt-immunity-equipment", "Player1", ""}
new_tree_copy.unit.count = 63
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "belt-immunity-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134671-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-weapon-shooting-speed", "AP-4-603"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-weapon-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 304
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136684-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "artillery", "AP-6-618"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "artillery", "Player1", ""}
new_tree_copy.unit.count = 305
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "artillery")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136562-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-research-speed", "AP-6-496"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-research-speed", "Player1", ""}
new_tree_copy.unit.count = 250
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135247-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-train-network", "AP-5-180"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-train-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 111
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131782-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-military", "AP-1-711"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-military", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 367
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133870-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-stronger-explosives", "AP-3-801"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-stronger-explosives", "Player1", ""}
new_tree_copy.unit.count = 430
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135760-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-personal-battery", "AP-5-693"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-personal-battery", "Player1", ""}
new_tree_copy.unit.count = 361
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "battery-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136001-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-military", "AP-5-934"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-military", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 470
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "military")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132714-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "personal-laser-defense-equipment", "AP-2-644"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "personal-laser-defense-equipment", "Player1", ""}
new_tree_copy.unit.count = 318
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "personal-laser-defense-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135328-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-efficiency-module", "AP-5-261"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-efficiency-module", "Player1", ""}
new_tree_copy.unit.count = 142
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "efficiency-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132854-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-wall", "AP-2-784"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-wall", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 405
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "stone-wall")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136335-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-electric-energy-distribution", "AP-6-269"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-electric-energy-distribution", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 148
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "electric-energy-distribution-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136812-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-vehicle", "AP-6-746"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-vehicle", "Player1", ""}
new_tree_copy.unit.count = 385
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "automobilism")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132584-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "cliff-explosives", "AP-2-514"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "cliff-explosives", "Player1", ""}
new_tree_copy.unit.count = 262
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "cliff-explosives")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133623-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "discharge-defense-equipment", "AP-3-554"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "discharge-defense-equipment", "Player1", ""}
new_tree_copy.unit.count = 277
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "discharge-defense-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132959-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-vehicle", "AP-2-889"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-vehicle", "Player1", ""}
new_tree_copy.unit.count = 449
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "automobilism")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136158-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-flamethrower", "AP-6-092"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-flamethrower", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 72
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132543-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "low-density-structure", "AP-2-473"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "low-density-structure", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 241
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "low-density-structure")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134404-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "solar-panel-equipment", "AP-4-336"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "solar-panel-equipment", "Player1", ""}
new_tree_copy.unit.count = 182
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "solar-panel-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131266-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-advanced-material-processing", "AP-1-195"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-advanced-material-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 114
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "advanced-material-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134194-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-personal-roboport-equipment", "AP-4-126"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-personal-roboport-equipment", "Player1", ""}
new_tree_copy.unit.count = 96
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "personal-roboport-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135101-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-energy-shield", "AP-5-034"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-energy-shield", "Player1", ""}
new_tree_copy.unit.count = 32
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "energy-shield-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131565-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-train-network", "AP-1-494"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-train-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 248
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136183-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-train-network", "AP-6-117"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-train-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 86
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136643-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-turret", "AP-6-577"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-turret", "Player1", ""}
new_tree_copy.unit.count = 290
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "gun-turret")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135539-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-research-speed", "AP-5-472"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-research-speed", "Player1", ""}
new_tree_copy.unit.count = 236
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "research-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132722-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-flamethrower", "AP-2-652"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-flamethrower", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 330
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "flamethrower")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133132-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-train-network", "AP-3-063"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-train-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 42
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136803-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-weapons-damage", "AP-6-737"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-weapons-damage", "Player1", ""}
new_tree_copy.unit.count = 382
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134949-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-worker-robots-speed", "AP-4-881"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-worker-robots-speed", "Player1", ""}
new_tree_copy.unit.count = 445
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134344-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-weapons-damage", "AP-4-276"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-weapons-damage", "Player1", ""}
new_tree_copy.unit.count = 169
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135628-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-inserter", "AP-5-561"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-inserter", "Player1", ""}
new_tree_copy.unit.count = 278
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136642-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-weapon-shooting-speed", "AP-6-576"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-weapon-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 280
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "weapon-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134746-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-wall", "AP-4-678"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-wall", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 341
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "stone-wall")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136437-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-armor", "AP-6-371"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-armor", "Player1", ""}
new_tree_copy.unit.count = 194
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134891-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-fluid-handling", "AP-4-823"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-fluid-handling", "Player1", ""}
new_tree_copy.unit.count = 433
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fluid-handling")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133802-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-processing", "AP-3-733"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 374
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133387-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-processing", "AP-3-318"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 180
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133148-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-inserter", "AP-3-079"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-inserter", "Player1", ""}
new_tree_copy.unit.count = 72
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133606-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-automation", "AP-3-537"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-automation", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 276
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133743-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-stronger-explosives", "AP-3-674"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-stronger-explosives", "Player1", ""}
new_tree_copy.unit.count = 333
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131401-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-train-network", "AP-1-330"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-train-network", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 182
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "railway")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135666-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-speed-module", "AP-5-599"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-speed-module", "Player1", ""}
new_tree_copy.unit.count = 303
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "speed-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136472-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-processing", "AP-6-406"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 201
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "steel-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135365-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-follower-robot-count", "AP-5-298"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-follower-robot-count", "Player1", ""}
new_tree_copy.unit.count = 175
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "follower-robot-count-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134595-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-rocketry", "AP-4-527"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-rocketry", "Player1", ""}
new_tree_copy.unit.count = 267
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "rocketry")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136866-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-productivity-module", "AP-6-800"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-productivity-module", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 429
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "productivity-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134995-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-armor", "AP-4-927"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-armor", "Player1", ""}
new_tree_copy.unit.count = 470
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131229-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-armor", "AP-1-158"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-armor", "Player1", ""}
new_tree_copy.unit.count = 104
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "heavy-armor")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136387-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-shooting-speed", "AP-6-321"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-shooting-speed", "Player1", ""}
new_tree_copy.unit.count = 180
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-shooting-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135423-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-engine", "AP-5-356"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-engine", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 190
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "engine")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132005-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-worker-robots-speed", "AP-1-934"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-worker-robots-speed", "Player1", ""}
new_tree_copy.unit.count = 470
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134717-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "logistic-system", "AP-4-649"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "logistic-system", "Player1", ""}
new_tree_copy.unit.count = 325
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "logistic-system")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131179-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-inserter", "AP-1-108"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-inserter", "Player1", ""}
new_tree_copy.unit.count = 82
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136020-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-science-pack", "AP-5-953"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-science-pack", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 478
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "logistic-science-pack")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132325-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-advanced-material-processing", "AP-2-255"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-advanced-material-processing", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 142
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "advanced-material-processing")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133175-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-fluid-handling", "AP-3-106"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-fluid-handling", "Player1", ""}
new_tree_copy.unit.count = 80
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fluid-handling")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132864-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-worker-robots-speed", "AP-2-794"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-worker-robots-speed", "Player1", ""}
new_tree_copy.unit.count = 419
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "worker-robots-speed-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136136-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-stronger-explosives", "AP-6-070"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-stronger-explosives", "Player1", ""}
new_tree_copy.unit.count = 45
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "stronger-explosives-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136065-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-personal-roboport-equipment", "AP-5-998"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-personal-roboport-equipment", "Player1", ""}
new_tree_copy.unit.count = 498
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "personal-roboport-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135142-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-inserter", "AP-5-075"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-inserter", "Player1", ""}
new_tree_copy.unit.count = 48
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131102-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-automation", "AP-1-031"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-automation", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 10
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133112-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-follower", "AP-3-043"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-follower", "Player1", ""}
new_tree_copy.unit.count = 40
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "defender")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131724-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "plastics", "AP-1-653"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "plastics", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 332
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "plastics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132068-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-physical-projectile-damage", "AP-1-997"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-physical-projectile-damage", "Player1", ""}
new_tree_copy.unit.count = 497
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "physical-projectile-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136162-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-rocketry", "AP-6-096"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-rocketry", "Player1", ""}
new_tree_copy.unit.count = 72
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "rocketry")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131265-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "night-vision-equipment", "AP-1-194"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "night-vision-equipment", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 113
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "night-vision-equipment")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132561-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-laser-weapons-damage", "AP-2-491"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-laser-weapons-damage", "Player1", ""}
new_tree_copy.unit.count = 247
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "laser-weapons-damage-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133863-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "oil-gathering", "AP-3-794"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "oil-gathering", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 424
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "oil-gathering")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136750-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-efficiency-module", "AP-6-684"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-efficiency-module", "Player1", ""}
new_tree_copy.unit.count = 350
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "efficiency-module")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132408-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "progressive-electric-energy-distribution", "AP-2-338"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "progressive-electric-energy-distribution", "Player1", {"technology-description.ap-technology-item-advancement"}}
new_tree_copy.unit.count = 185
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "electric-energy-distribution-1")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136751-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "construction-robotics", "AP-6-685"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "construction-robotics", "Player1", ""}
new_tree_copy.unit.count = 355
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "construction-robotics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132833-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "steel-axe", "AP-2-763"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "steel-axe", "Player1", ""}
new_tree_copy.unit.count = 399
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "steel-axe")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131570-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "electric-energy-accumulators", "AP-1-499"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "electric-energy-accumulators", "Player1", ""}
new_tree_copy.unit.count = 253
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "electric-energy-accumulators")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132639-"
new_tree_copy.localised_name = {"technology-name.ap-technology-full", "Player1", "uranium-ammo", "AP-2-569"}
new_tree_copy.localised_description  = {"technology-description.ap-technology-full", "uranium-ammo", "Player1", ""}
new_tree_copy.unit.count = 279
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}

copy_factorio_icon(new_tree_copy, "uranium-ammo")
data:extend{new_tree_copy}

