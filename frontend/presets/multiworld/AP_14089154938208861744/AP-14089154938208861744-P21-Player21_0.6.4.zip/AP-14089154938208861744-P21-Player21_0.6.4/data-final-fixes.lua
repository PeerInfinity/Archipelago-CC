
-- this file gets written automatically by the Archipelago Randomizer and is in its raw form a Jinja2 Template
require('lib')
data.raw["item"]["rocket-part"].hidden = false
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes = {
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { 0, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { 0, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, 0 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, 0 } }
        }
    },
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { -3, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { -3, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, -3 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, -3 } }
        }
    },
    {
        production_type = "input",
        pipe_picture = assembler2pipepictures(),
        pipe_covers = pipecoverspictures(),
        volume = 1000,
        base_area = 10,
        base_level = -1,
        pipe_connections = {
            { flow_direction = "input", direction = defines.direction.south, position = { 3, 4.2 } },
            { flow_direction = "input", direction = defines.direction.north, position = { 3, -4.2 } },
            { flow_direction = "input", direction = defines.direction.east, position = { 4.2, 3 } },
            { flow_direction = "input", direction = defines.direction.west, position = { -4.2, 3 } }
        }
    }
}
data.raw["rocket-silo"]["rocket-silo"].fluid_boxes_off_when_no_fluid_recipe = true
data.raw["recipe"]["rocket-part"].category = "rocket-building"
data.raw["recipe"]["rocket-part"].ingredients = {{type = "item", name = "cluster-grenade", amount = 10},
{type = "item", name = "flamethrower-turret", amount = 10},
{type = "item", name = "rocket-fuel", amount = 10}
}
data.raw["recipe"]["ap-energy-bridge"].category = "crafting"
data.raw["recipe"]["ap-energy-bridge"].ingredients = {{type = "item", name = "transport-belt", amount = 305},
{type = "item", name = "stone-brick", amount = 127},
{type = "item", name = "stone", amount = 251},
{type = "item", name = "pipe", amount = 470},
{type = "item", name = "iron-plate", amount = 179},
{type = "item", name = "iron-ore", amount = 302}
}

local technologies = data.raw["technology"]
local new_tree_copy

local template_tech = table.deepcopy(technologies["automation"])
template_tech.unlocks = {}
template_tech.upgrade = false
template_tech.effects = {}
template_tech.prerequisites = {}

function set_ap_icon(tech)
    tech.icon = "__AP-14089154938208861744-P21-Player21__/graphics/icons/ap.png"
    tech.icons = nil
    tech.icon_size = 128
end

function set_ap_unimportant_icon(tech)
    tech.icon = "__AP-14089154938208861744-P21-Player21__/graphics/icons/ap_unimportant.png"
    tech.icons = nil
    tech.icon_size = 128
end

function copy_factorio_icon(tech, tech_source)
    tech.icon = table.deepcopy(technologies[tech_source].icon)
    tech.icons = table.deepcopy(technologies[tech_source].icons)
    tech.icon_size = table.deepcopy(technologies[tech_source].icon_size)
end


function adjust_energy(recipe_name, factor)
    local recipe = data.raw.recipe[recipe_name]
    local energy = recipe.energy_required

    if (recipe.normal ~= nil) then
        if (recipe.normal.energy_required == nil) then
            energy = 0.5
        else
            energy = recipe.normal.energy_required
        end
        recipe.normal.energy_required = energy * factor
    end
    if (recipe.expensive ~= nil) then
        if (recipe.expensive.energy_required == nil) then
            energy = 0.5
        else
            energy = recipe.expensive.energy_required
        end
        recipe.expensive.energy_required = energy * factor
    end
    if (energy ~= nil) then
        data.raw.recipe[recipe_name].energy_required = energy * factor
    elseif (recipe.expensive == nil and recipe.normal == nil) then
        data.raw.recipe[recipe_name].energy_required = 0.5 * factor
    end
end

function set_energy(recipe_name, energy)
    local recipe = data.raw.recipe[recipe_name]

    if (recipe.normal ~= nil) then
        recipe.normal.energy_required = energy
    end
    if (recipe.expensive ~= nil) then
        recipe.expensive.energy_required = energy
    end
    if (recipe.expensive == nil and recipe.normal == nil) then
        recipe.energy_required = energy
    end
end

data.raw["assembling-machine"]["assembling-machine-1"].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
data.raw["assembling-machine"]["assembling-machine-2"].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
data.raw["assembling-machine"]["assembling-machine-1"].fluid_boxes = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes)
if mods["factory-levels"] then
    -- Factory-Levels allows the assembling machines to get faster (and depending on settings), more productive at crafting products, the more the
    -- assembling machine crafts the product.  If the machine crafts enough, it may auto-upgrade to the next tier.
    for i = 1, 25, 1 do
        data.raw["assembling-machine"]["assembling-machine-1-level-" .. i].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
        data.raw["assembling-machine"]["assembling-machine-1-level-" .. i].fluid_boxes = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-2"].fluid_boxes)
    end
    for i = 1, 50, 1 do
        data.raw["assembling-machine"]["assembling-machine-2-level-" .. i].crafting_categories = table.deepcopy(data.raw["assembling-machine"]["assembling-machine-3"].crafting_categories)
    end
end

data.raw["ammo"]["artillery-shell"].stack_size = 10

technologies["advanced-circuit"].hidden = true
technologies["advanced-circuit"].hidden_in_factoriopedia = true
technologies["advanced-combinators"].hidden = true
technologies["advanced-combinators"].hidden_in_factoriopedia = true
technologies["advanced-material-processing"].hidden = true
technologies["advanced-material-processing"].hidden_in_factoriopedia = true
technologies["advanced-material-processing-2"].hidden = true
technologies["advanced-material-processing-2"].hidden_in_factoriopedia = true
technologies["advanced-oil-processing"].hidden = true
technologies["advanced-oil-processing"].hidden_in_factoriopedia = true
technologies["artillery"].hidden = true
technologies["artillery"].hidden_in_factoriopedia = true
technologies["atomic-bomb"].hidden = true
technologies["atomic-bomb"].hidden_in_factoriopedia = true
technologies["automated-rail-transportation"].hidden = true
technologies["automated-rail-transportation"].hidden_in_factoriopedia = true
technologies["automation"].hidden = true
technologies["automation"].hidden_in_factoriopedia = true
technologies["automation-2"].hidden = true
technologies["automation-2"].hidden_in_factoriopedia = true
technologies["automation-3"].hidden = true
technologies["automation-3"].hidden_in_factoriopedia = true
technologies["automation-science-pack"].hidden = true
technologies["automation-science-pack"].hidden_in_factoriopedia = true
technologies["automobilism"].hidden = true
technologies["automobilism"].hidden_in_factoriopedia = true
technologies["battery"].hidden = true
technologies["battery"].hidden_in_factoriopedia = true
technologies["battery-equipment"].hidden = true
technologies["battery-equipment"].hidden_in_factoriopedia = true
technologies["battery-mk2-equipment"].hidden = true
technologies["battery-mk2-equipment"].hidden_in_factoriopedia = true
technologies["belt-immunity-equipment"].hidden = true
technologies["belt-immunity-equipment"].hidden_in_factoriopedia = true
technologies["braking-force-1"].hidden = true
technologies["braking-force-1"].hidden_in_factoriopedia = true
technologies["braking-force-2"].hidden = true
technologies["braking-force-2"].hidden_in_factoriopedia = true
technologies["braking-force-3"].hidden = true
technologies["braking-force-3"].hidden_in_factoriopedia = true
technologies["braking-force-4"].hidden = true
technologies["braking-force-4"].hidden_in_factoriopedia = true
technologies["braking-force-5"].hidden = true
technologies["braking-force-5"].hidden_in_factoriopedia = true
technologies["braking-force-6"].hidden = true
technologies["braking-force-6"].hidden_in_factoriopedia = true
technologies["braking-force-7"].hidden = true
technologies["braking-force-7"].hidden_in_factoriopedia = true
technologies["bulk-inserter"].hidden = true
technologies["bulk-inserter"].hidden_in_factoriopedia = true
technologies["chemical-science-pack"].hidden = true
technologies["chemical-science-pack"].hidden_in_factoriopedia = true
technologies["circuit-network"].hidden = true
technologies["circuit-network"].hidden_in_factoriopedia = true
technologies["cliff-explosives"].hidden = true
technologies["cliff-explosives"].hidden_in_factoriopedia = true
technologies["coal-liquefaction"].hidden = true
technologies["coal-liquefaction"].hidden_in_factoriopedia = true
technologies["concrete"].hidden = true
technologies["concrete"].hidden_in_factoriopedia = true
technologies["construction-robotics"].hidden = true
technologies["construction-robotics"].hidden_in_factoriopedia = true
technologies["defender"].hidden = true
technologies["defender"].hidden_in_factoriopedia = true
technologies["destroyer"].hidden = true
technologies["destroyer"].hidden_in_factoriopedia = true
technologies["discharge-defense-equipment"].hidden = true
technologies["discharge-defense-equipment"].hidden_in_factoriopedia = true
technologies["distractor"].hidden = true
technologies["distractor"].hidden_in_factoriopedia = true
technologies["effect-transmission"].hidden = true
technologies["effect-transmission"].hidden_in_factoriopedia = true
technologies["efficiency-module"].hidden = true
technologies["efficiency-module"].hidden_in_factoriopedia = true
technologies["efficiency-module-2"].hidden = true
technologies["efficiency-module-2"].hidden_in_factoriopedia = true
technologies["efficiency-module-3"].hidden = true
technologies["efficiency-module-3"].hidden_in_factoriopedia = true
technologies["electric-energy-accumulators"].hidden = true
technologies["electric-energy-accumulators"].hidden_in_factoriopedia = true
technologies["electric-energy-distribution-1"].hidden = true
technologies["electric-energy-distribution-1"].hidden_in_factoriopedia = true
technologies["electric-energy-distribution-2"].hidden = true
technologies["electric-energy-distribution-2"].hidden_in_factoriopedia = true
technologies["electric-engine"].hidden = true
technologies["electric-engine"].hidden_in_factoriopedia = true
technologies["electric-mining-drill"].hidden = true
technologies["electric-mining-drill"].hidden_in_factoriopedia = true
technologies["electronics"].hidden = true
technologies["electronics"].hidden_in_factoriopedia = true
technologies["energy-shield-equipment"].hidden = true
technologies["energy-shield-equipment"].hidden_in_factoriopedia = true
technologies["energy-shield-mk2-equipment"].hidden = true
technologies["energy-shield-mk2-equipment"].hidden_in_factoriopedia = true
technologies["engine"].hidden = true
technologies["engine"].hidden_in_factoriopedia = true
technologies["exoskeleton-equipment"].hidden = true
technologies["exoskeleton-equipment"].hidden_in_factoriopedia = true
technologies["explosive-rocketry"].hidden = true
technologies["explosive-rocketry"].hidden_in_factoriopedia = true
technologies["explosives"].hidden = true
technologies["explosives"].hidden_in_factoriopedia = true
technologies["fast-inserter"].hidden = true
technologies["fast-inserter"].hidden_in_factoriopedia = true
technologies["fission-reactor-equipment"].hidden = true
technologies["fission-reactor-equipment"].hidden_in_factoriopedia = true
technologies["flamethrower"].hidden = true
technologies["flamethrower"].hidden_in_factoriopedia = true
technologies["flammables"].hidden = true
technologies["flammables"].hidden_in_factoriopedia = true
technologies["fluid-handling"].hidden = true
technologies["fluid-handling"].hidden_in_factoriopedia = true
technologies["fluid-wagon"].hidden = true
technologies["fluid-wagon"].hidden_in_factoriopedia = true
technologies["follower-robot-count-1"].hidden = true
technologies["follower-robot-count-1"].hidden_in_factoriopedia = true
technologies["follower-robot-count-2"].hidden = true
technologies["follower-robot-count-2"].hidden_in_factoriopedia = true
technologies["follower-robot-count-3"].hidden = true
technologies["follower-robot-count-3"].hidden_in_factoriopedia = true
technologies["follower-robot-count-4"].hidden = true
technologies["follower-robot-count-4"].hidden_in_factoriopedia = true
technologies["gate"].hidden = true
technologies["gate"].hidden_in_factoriopedia = true
technologies["gun-turret"].hidden = true
technologies["gun-turret"].hidden_in_factoriopedia = true
technologies["heavy-armor"].hidden = true
technologies["heavy-armor"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-1"].hidden = true
technologies["inserter-capacity-bonus-1"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-2"].hidden = true
technologies["inserter-capacity-bonus-2"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-3"].hidden = true
technologies["inserter-capacity-bonus-3"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-4"].hidden = true
technologies["inserter-capacity-bonus-4"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-5"].hidden = true
technologies["inserter-capacity-bonus-5"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-6"].hidden = true
technologies["inserter-capacity-bonus-6"].hidden_in_factoriopedia = true
technologies["inserter-capacity-bonus-7"].hidden = true
technologies["inserter-capacity-bonus-7"].hidden_in_factoriopedia = true
technologies["kovarex-enrichment-process"].hidden = true
technologies["kovarex-enrichment-process"].hidden_in_factoriopedia = true
technologies["lamp"].hidden = true
technologies["lamp"].hidden_in_factoriopedia = true
technologies["land-mine"].hidden = true
technologies["land-mine"].hidden_in_factoriopedia = true
technologies["landfill"].hidden = true
technologies["landfill"].hidden_in_factoriopedia = true
technologies["laser"].hidden = true
technologies["laser"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-1"].hidden = true
technologies["laser-shooting-speed-1"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-2"].hidden = true
technologies["laser-shooting-speed-2"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-3"].hidden = true
technologies["laser-shooting-speed-3"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-4"].hidden = true
technologies["laser-shooting-speed-4"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-5"].hidden = true
technologies["laser-shooting-speed-5"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-6"].hidden = true
technologies["laser-shooting-speed-6"].hidden_in_factoriopedia = true
technologies["laser-shooting-speed-7"].hidden = true
technologies["laser-shooting-speed-7"].hidden_in_factoriopedia = true
technologies["laser-turret"].hidden = true
technologies["laser-turret"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-1"].hidden = true
technologies["laser-weapons-damage-1"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-2"].hidden = true
technologies["laser-weapons-damage-2"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-3"].hidden = true
technologies["laser-weapons-damage-3"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-4"].hidden = true
technologies["laser-weapons-damage-4"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-5"].hidden = true
technologies["laser-weapons-damage-5"].hidden_in_factoriopedia = true
technologies["laser-weapons-damage-6"].hidden = true
technologies["laser-weapons-damage-6"].hidden_in_factoriopedia = true
technologies["logistic-robotics"].hidden = true
technologies["logistic-robotics"].hidden_in_factoriopedia = true
technologies["logistic-science-pack"].hidden = true
technologies["logistic-science-pack"].hidden_in_factoriopedia = true
technologies["logistic-system"].hidden = true
technologies["logistic-system"].hidden_in_factoriopedia = true
technologies["logistics"].hidden = true
technologies["logistics"].hidden_in_factoriopedia = true
technologies["logistics-2"].hidden = true
technologies["logistics-2"].hidden_in_factoriopedia = true
technologies["logistics-3"].hidden = true
technologies["logistics-3"].hidden_in_factoriopedia = true
technologies["low-density-structure"].hidden = true
technologies["low-density-structure"].hidden_in_factoriopedia = true
technologies["lubricant"].hidden = true
technologies["lubricant"].hidden_in_factoriopedia = true
technologies["military"].hidden = true
technologies["military"].hidden_in_factoriopedia = true
technologies["military-2"].hidden = true
technologies["military-2"].hidden_in_factoriopedia = true
technologies["military-3"].hidden = true
technologies["military-3"].hidden_in_factoriopedia = true
technologies["military-4"].hidden = true
technologies["military-4"].hidden_in_factoriopedia = true
technologies["military-science-pack"].hidden = true
technologies["military-science-pack"].hidden_in_factoriopedia = true
technologies["mining-productivity-1"].hidden = true
technologies["mining-productivity-1"].hidden_in_factoriopedia = true
technologies["mining-productivity-2"].hidden = true
technologies["mining-productivity-2"].hidden_in_factoriopedia = true
technologies["mining-productivity-3"].hidden = true
technologies["mining-productivity-3"].hidden_in_factoriopedia = true
technologies["modular-armor"].hidden = true
technologies["modular-armor"].hidden_in_factoriopedia = true
technologies["modules"].hidden = true
technologies["modules"].hidden_in_factoriopedia = true
technologies["night-vision-equipment"].hidden = true
technologies["night-vision-equipment"].hidden_in_factoriopedia = true
technologies["nuclear-fuel-reprocessing"].hidden = true
technologies["nuclear-fuel-reprocessing"].hidden_in_factoriopedia = true
technologies["nuclear-power"].hidden = true
technologies["nuclear-power"].hidden_in_factoriopedia = true
technologies["oil-gathering"].hidden = true
technologies["oil-gathering"].hidden_in_factoriopedia = true
technologies["oil-processing"].hidden = true
technologies["oil-processing"].hidden_in_factoriopedia = true
technologies["personal-laser-defense-equipment"].hidden = true
technologies["personal-laser-defense-equipment"].hidden_in_factoriopedia = true
technologies["personal-roboport-equipment"].hidden = true
technologies["personal-roboport-equipment"].hidden_in_factoriopedia = true
technologies["personal-roboport-mk2-equipment"].hidden = true
technologies["personal-roboport-mk2-equipment"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-1"].hidden = true
technologies["physical-projectile-damage-1"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-2"].hidden = true
technologies["physical-projectile-damage-2"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-3"].hidden = true
technologies["physical-projectile-damage-3"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-4"].hidden = true
technologies["physical-projectile-damage-4"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-5"].hidden = true
technologies["physical-projectile-damage-5"].hidden_in_factoriopedia = true
technologies["physical-projectile-damage-6"].hidden = true
technologies["physical-projectile-damage-6"].hidden_in_factoriopedia = true
technologies["plastics"].hidden = true
technologies["plastics"].hidden_in_factoriopedia = true
technologies["power-armor"].hidden = true
technologies["power-armor"].hidden_in_factoriopedia = true
technologies["power-armor-mk2"].hidden = true
technologies["power-armor-mk2"].hidden_in_factoriopedia = true
technologies["processing-unit"].hidden = true
technologies["processing-unit"].hidden_in_factoriopedia = true
technologies["production-science-pack"].hidden = true
technologies["production-science-pack"].hidden_in_factoriopedia = true
technologies["productivity-module"].hidden = true
technologies["productivity-module"].hidden_in_factoriopedia = true
technologies["productivity-module-2"].hidden = true
technologies["productivity-module-2"].hidden_in_factoriopedia = true
technologies["productivity-module-3"].hidden = true
technologies["productivity-module-3"].hidden_in_factoriopedia = true
technologies["radar"].hidden = true
technologies["radar"].hidden_in_factoriopedia = true
technologies["railway"].hidden = true
technologies["railway"].hidden_in_factoriopedia = true
technologies["refined-flammables-1"].hidden = true
technologies["refined-flammables-1"].hidden_in_factoriopedia = true
technologies["refined-flammables-2"].hidden = true
technologies["refined-flammables-2"].hidden_in_factoriopedia = true
technologies["refined-flammables-3"].hidden = true
technologies["refined-flammables-3"].hidden_in_factoriopedia = true
technologies["refined-flammables-4"].hidden = true
technologies["refined-flammables-4"].hidden_in_factoriopedia = true
technologies["refined-flammables-5"].hidden = true
technologies["refined-flammables-5"].hidden_in_factoriopedia = true
technologies["refined-flammables-6"].hidden = true
technologies["refined-flammables-6"].hidden_in_factoriopedia = true
technologies["repair-pack"].hidden = true
technologies["repair-pack"].hidden_in_factoriopedia = true
technologies["research-speed-1"].hidden = true
technologies["research-speed-1"].hidden_in_factoriopedia = true
technologies["research-speed-2"].hidden = true
technologies["research-speed-2"].hidden_in_factoriopedia = true
technologies["research-speed-3"].hidden = true
technologies["research-speed-3"].hidden_in_factoriopedia = true
technologies["research-speed-4"].hidden = true
technologies["research-speed-4"].hidden_in_factoriopedia = true
technologies["research-speed-5"].hidden = true
technologies["research-speed-5"].hidden_in_factoriopedia = true
technologies["research-speed-6"].hidden = true
technologies["research-speed-6"].hidden_in_factoriopedia = true
technologies["robotics"].hidden = true
technologies["robotics"].hidden_in_factoriopedia = true
technologies["rocket-fuel"].hidden = true
technologies["rocket-fuel"].hidden_in_factoriopedia = true
technologies["rocket-silo"].hidden = true
technologies["rocket-silo"].hidden_in_factoriopedia = true
technologies["rocketry"].hidden = true
technologies["rocketry"].hidden_in_factoriopedia = true
technologies["solar-energy"].hidden = true
technologies["solar-energy"].hidden_in_factoriopedia = true
technologies["solar-panel-equipment"].hidden = true
technologies["solar-panel-equipment"].hidden_in_factoriopedia = true
technologies["space-science-pack"].hidden = true
technologies["space-science-pack"].hidden_in_factoriopedia = true
technologies["speed-module"].hidden = true
technologies["speed-module"].hidden_in_factoriopedia = true
technologies["speed-module-2"].hidden = true
technologies["speed-module-2"].hidden_in_factoriopedia = true
technologies["speed-module-3"].hidden = true
technologies["speed-module-3"].hidden_in_factoriopedia = true
technologies["spidertron"].hidden = true
technologies["spidertron"].hidden_in_factoriopedia = true
technologies["steam-power"].hidden = true
technologies["steam-power"].hidden_in_factoriopedia = true
technologies["steel-axe"].hidden = true
technologies["steel-axe"].hidden_in_factoriopedia = true
technologies["steel-processing"].hidden = true
technologies["steel-processing"].hidden_in_factoriopedia = true
technologies["stone-wall"].hidden = true
technologies["stone-wall"].hidden_in_factoriopedia = true
technologies["stronger-explosives-1"].hidden = true
technologies["stronger-explosives-1"].hidden_in_factoriopedia = true
technologies["stronger-explosives-2"].hidden = true
technologies["stronger-explosives-2"].hidden_in_factoriopedia = true
technologies["stronger-explosives-3"].hidden = true
technologies["stronger-explosives-3"].hidden_in_factoriopedia = true
technologies["stronger-explosives-4"].hidden = true
technologies["stronger-explosives-4"].hidden_in_factoriopedia = true
technologies["stronger-explosives-5"].hidden = true
technologies["stronger-explosives-5"].hidden_in_factoriopedia = true
technologies["stronger-explosives-6"].hidden = true
technologies["stronger-explosives-6"].hidden_in_factoriopedia = true
technologies["sulfur-processing"].hidden = true
technologies["sulfur-processing"].hidden_in_factoriopedia = true
technologies["tank"].hidden = true
technologies["tank"].hidden_in_factoriopedia = true
technologies["toolbelt"].hidden = true
technologies["toolbelt"].hidden_in_factoriopedia = true
technologies["uranium-ammo"].hidden = true
technologies["uranium-ammo"].hidden_in_factoriopedia = true
technologies["uranium-mining"].hidden = true
technologies["uranium-mining"].hidden_in_factoriopedia = true
technologies["uranium-processing"].hidden = true
technologies["uranium-processing"].hidden_in_factoriopedia = true
technologies["utility-science-pack"].hidden = true
technologies["utility-science-pack"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-1"].hidden = true
technologies["weapon-shooting-speed-1"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-2"].hidden = true
technologies["weapon-shooting-speed-2"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-3"].hidden = true
technologies["weapon-shooting-speed-3"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-4"].hidden = true
technologies["weapon-shooting-speed-4"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-5"].hidden = true
technologies["weapon-shooting-speed-5"].hidden_in_factoriopedia = true
technologies["weapon-shooting-speed-6"].hidden = true
technologies["weapon-shooting-speed-6"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-1"].hidden = true
technologies["worker-robots-speed-1"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-2"].hidden = true
technologies["worker-robots-speed-2"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-3"].hidden = true
technologies["worker-robots-speed-3"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-4"].hidden = true
technologies["worker-robots-speed-4"].hidden_in_factoriopedia = true
technologies["worker-robots-speed-5"].hidden = true
technologies["worker-robots-speed-5"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-1"].hidden = true
technologies["worker-robots-storage-1"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-2"].hidden = true
technologies["worker-robots-storage-2"].hidden_in_factoriopedia = true
technologies["worker-robots-storage-3"].hidden = true
technologies["worker-robots-storage-3"].hidden_in_factoriopedia = true

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136257-"
new_tree_copy.unit.count = 100
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135441-"
new_tree_copy.unit.count = 219
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136408-"
new_tree_copy.unit.count = 213
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132319-"
new_tree_copy.unit.count = 178
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132086-"
new_tree_copy.unit.count = 22
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133260-"
new_tree_copy.unit.count = 106
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131105-"
new_tree_copy.unit.count = 10
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "automation")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134211-"
new_tree_copy.unit.count = 73
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135955-"
new_tree_copy.unit.count = 440
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132180-"
new_tree_copy.unit.count = 52
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133869-"
new_tree_copy.unit.count = 413
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134155-"
new_tree_copy.unit.count = 39
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134042-"
new_tree_copy.unit.count = 489
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131619-"
new_tree_copy.unit.count = 293
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132293-"
new_tree_copy.unit.count = 166
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135686-"
new_tree_copy.unit.count = 346
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-137053-"
new_tree_copy.unit.count = 491
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "rocket-silo")
table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 1: cluster-grenade"})

table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 2: flamethrower-turret"})

table.insert(new_tree_copy.effects, {type = "nothing", effect_description = "Ingredient 3: rocket-fuel"})

data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132948-"
new_tree_copy.unit.count = 440
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136485-"
new_tree_copy.unit.count = 248
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131194-"
new_tree_copy.unit.count = 55
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133601-"
new_tree_copy.unit.count = 286
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132803-"
new_tree_copy.unit.count = 376
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135381-"
new_tree_copy.unit.count = 210
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133314-"
new_tree_copy.unit.count = 172
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136407-"
new_tree_copy.unit.count = 211
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135806-"
new_tree_copy.unit.count = 387
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132314-"
new_tree_copy.unit.count = 172
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134853-"
new_tree_copy.unit.count = 409
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132072-"
new_tree_copy.unit.count = 5
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131530-"
new_tree_copy.unit.count = 268
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135222-"
new_tree_copy.unit.count = 83
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134924-"
new_tree_copy.unit.count = 435
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132646-"
new_tree_copy.unit.count = 315
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131398-"
new_tree_copy.unit.count = 210
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136931-"
new_tree_copy.unit.count = 437
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133832-"
new_tree_copy.unit.count = 394
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132242-"
new_tree_copy.unit.count = 90
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136548-"
new_tree_copy.unit.count = 274
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131242-"
new_tree_copy.unit.count = 90
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133266-"
new_tree_copy.unit.count = 115
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136155-"
new_tree_copy.unit.count = 45
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132900-"
new_tree_copy.unit.count = 421
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135001-"
new_tree_copy.unit.count = 476
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135685-"
new_tree_copy.unit.count = 345
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132341-"
new_tree_copy.unit.count = 200
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136000-"
new_tree_copy.unit.count = 477
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136893-"
new_tree_copy.unit.count = 421
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135608-"
new_tree_copy.unit.count = 292
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134762-"
new_tree_copy.unit.count = 366
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136783-"
new_tree_copy.unit.count = 374
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132543-"
new_tree_copy.unit.count = 274
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "fast-inserter")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132524-"
new_tree_copy.unit.count = 266
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136312-"
new_tree_copy.unit.count = 176
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134311-"
new_tree_copy.unit.count = 171
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131972-"
new_tree_copy.unit.count = 451
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136588-"
new_tree_copy.unit.count = 285
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133649-"
new_tree_copy.unit.count = 317
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135270-"
new_tree_copy.unit.count = 131
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134044-"
new_tree_copy.unit.count = 489
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131135-"
new_tree_copy.unit.count = 10
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}copy_factorio_icon(new_tree_copy, "logistics")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132422-"
new_tree_copy.unit.count = 216
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133924-"
new_tree_copy.unit.count = 432
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136458-"
new_tree_copy.unit.count = 237
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134982-"
new_tree_copy.unit.count = 461
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134740-"
new_tree_copy.unit.count = 364
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131685-"
new_tree_copy.unit.count = 337
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131282-"
new_tree_copy.unit.count = 142
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131338-"
new_tree_copy.unit.count = 189
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133432-"
new_tree_copy.unit.count = 216
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132200-"
new_tree_copy.unit.count = 60
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134911-"
new_tree_copy.unit.count = 426
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136683-"
new_tree_copy.unit.count = 344
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134823-"
new_tree_copy.unit.count = 394
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131337-"
new_tree_copy.unit.count = 185
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131868-"
new_tree_copy.unit.count = 412
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134635-"
new_tree_copy.unit.count = 310
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136287-"
new_tree_copy.unit.count = 161
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136231-"
new_tree_copy.unit.count = 85
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136357-"
new_tree_copy.unit.count = 202
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133223-"
new_tree_copy.unit.count = 80
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133170-"
new_tree_copy.unit.count = 51
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135291-"
new_tree_copy.unit.count = 167
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135786-"
new_tree_copy.unit.count = 376
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132237-"
new_tree_copy.unit.count = 85
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133958-"
new_tree_copy.unit.count = 441
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132951-"
new_tree_copy.unit.count = 440
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133242-"
new_tree_copy.unit.count = 94
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134115-"
new_tree_copy.unit.count = 29
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136471-"
new_tree_copy.unit.count = 237
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134323-"
new_tree_copy.unit.count = 181
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135066-"
new_tree_copy.unit.count = 496
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131666-"
new_tree_copy.unit.count = 331
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134267-"
new_tree_copy.unit.count = 119
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134653-"
new_tree_copy.unit.count = 321
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132027-"
new_tree_copy.unit.count = 488
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135473-"
new_tree_copy.unit.count = 239
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133507-"
new_tree_copy.unit.count = 251
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136968-"
new_tree_copy.unit.count = 452
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136267-"
new_tree_copy.unit.count = 128
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132992-"
new_tree_copy.unit.count = 475
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131855-"
new_tree_copy.unit.count = 405
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134438-"
new_tree_copy.unit.count = 217
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135621-"
new_tree_copy.unit.count = 305
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132852-"
new_tree_copy.unit.count = 400
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136196-"
new_tree_copy.unit.count = 63
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131484-"
new_tree_copy.unit.count = 247
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135630-"
new_tree_copy.unit.count = 308
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132437-"
new_tree_copy.unit.count = 217
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134063-"
new_tree_copy.unit.count = 492
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133202-"
new_tree_copy.unit.count = 66
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133564-"
new_tree_copy.unit.count = 279
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136255-"
new_tree_copy.unit.count = 94
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134833-"
new_tree_copy.unit.count = 395
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133280-"
new_tree_copy.unit.count = 157
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135262-"
new_tree_copy.unit.count = 107
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-137008-"
new_tree_copy.unit.count = 479
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133684-"
new_tree_copy.unit.count = 339
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133083-"
new_tree_copy.unit.count = 18
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134704-"
new_tree_copy.unit.count = 351
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136301-"
new_tree_copy.unit.count = 168
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134902-"
new_tree_copy.unit.count = 426
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131604-"
new_tree_copy.unit.count = 289
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133138-"
new_tree_copy.unit.count = 34
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136809-"
new_tree_copy.unit.count = 387
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133205-"
new_tree_copy.unit.count = 72
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133517-"
new_tree_copy.unit.count = 259
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131368-"
new_tree_copy.unit.count = 209
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133136-"
new_tree_copy.unit.count = 31
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132699-"
new_tree_copy.unit.count = 349
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132127-"
new_tree_copy.unit.count = 30
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136688-"
new_tree_copy.unit.count = 348
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}
copy_factorio_icon(new_tree_copy, "solar-energy")
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133803-"
new_tree_copy.unit.count = 377
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135939-"
new_tree_copy.unit.count = 438
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133080-"
new_tree_copy.unit.count = 7
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131806-"
new_tree_copy.unit.count = 379
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133448-"
new_tree_copy.unit.count = 224
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136727-"
new_tree_copy.unit.count = 360
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132355-"
new_tree_copy.unit.count = 200
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136839-"
new_tree_copy.unit.count = 396
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135493-"
new_tree_copy.unit.count = 249
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136512-"
new_tree_copy.unit.count = 253
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131461-"
new_tree_copy.unit.count = 230
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136176-"
new_tree_copy.unit.count = 53
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131556-"
new_tree_copy.unit.count = 276
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133986-"
new_tree_copy.unit.count = 463
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135444-"
new_tree_copy.unit.count = 220
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135535-"
new_tree_copy.unit.count = 271
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131859-"
new_tree_copy.unit.count = 411
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133479-"
new_tree_copy.unit.count = 243
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132677-"
new_tree_copy.unit.count = 332
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134214-"
new_tree_copy.unit.count = 76
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134032-"
new_tree_copy.unit.count = 489
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133580-"
new_tree_copy.unit.count = 284
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134578-"
new_tree_copy.unit.count = 280
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131281-"
new_tree_copy.unit.count = 142
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-131293-"
new_tree_copy.unit.count = 162
new_tree_copy.unit.ingredients = {{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132456-"
new_tree_copy.unit.count = 229
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136611-"
new_tree_copy.unit.count = 293
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134717-"
new_tree_copy.unit.count = 356
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135450-"
new_tree_copy.unit.count = 229
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136643-"
new_tree_copy.unit.count = 317
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
},
{"production-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132412-"
new_tree_copy.unit.count = 215
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135702-"
new_tree_copy.unit.count = 350
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133305-"
new_tree_copy.unit.count = 171
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133662-"
new_tree_copy.unit.count = 328
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136820-"
new_tree_copy.unit.count = 394
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135016-"
new_tree_copy.unit.count = 479
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132631-"
new_tree_copy.unit.count = 307
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136332-"
new_tree_copy.unit.count = 186
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134978-"
new_tree_copy.unit.count = 460
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-133675-"
new_tree_copy.unit.count = 332
new_tree_copy.unit.ingredients = {{"military-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134887-"
new_tree_copy.unit.count = 416
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135700-"
new_tree_copy.unit.count = 349
new_tree_copy.unit.ingredients = {{"production-science-pack",
1
},
{"automation-science-pack",
1
},
{"military-science-pack",
1
},
{"chemical-science-pack",
1
}
}set_ap_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132239-"
new_tree_copy.unit.count = 88
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-135007-"
new_tree_copy.unit.count = 478
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-132779-"
new_tree_copy.unit.count = 374
new_tree_copy.unit.ingredients = {{"logistic-science-pack",
1
},
{"automation-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134357-"
new_tree_copy.unit.count = 202
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"logistic-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-134275-"
new_tree_copy.unit.count = 135
new_tree_copy.unit.ingredients = {{"chemical-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

new_tree_copy = table.deepcopy(template_tech)
new_tree_copy.name = "ap-136959-"
new_tree_copy.unit.count = 447
new_tree_copy.unit.ingredients = {{"utility-science-pack",
1
},
{"automation-science-pack",
1
},
{"logistic-science-pack",
1
},
{"military-science-pack",
1
}
}set_ap_unimportant_icon(new_tree_copy)
data:extend{new_tree_copy}

